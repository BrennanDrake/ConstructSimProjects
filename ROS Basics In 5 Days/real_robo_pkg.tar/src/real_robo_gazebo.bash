#!/bin/bash


roslaunch realrobotlab main.launch